#include <stdio.h>

typedef unsigned short meter_t;

unsigned int consumption(meter_t previous, meter_t current)
{
    return (unsigned short)(current - previous);
}

int main(void)
{
    printf("Normal consumption: %u units\n",
           consumption(1200, 1530));

    printf("Rollover consumption: %u units\n",
           consumption(65400, 120));

    return 0;
}
